$(document).on('keypress', 'input,select', function(e) {
    // 1st section checking inputs
    if (e.which == 13) {
        var name = document.querySelector(":focus").value;
        var nameid = document.querySelector(":focus").id;
        console.log(nameid)
        if (name == '') {
            var error_fill_anim = document.getElementById(nameid);
            if (nameid == "mobile_number") {
                error_fill_anim = document.getElementById("mobile_number1");
                error_fill_anim.classList.add('animate__shakeX')
                setTimeout(function() {
                    error_fill_anim.classList.remove('animate__shakeX')
                }, 3000);
            } else {
                error_fill_anim.classList.add('animate__shakeX')
                setTimeout(function() {
                    error_fill_anim.classList.remove('animate__shakeX')
                }, 3000);
            }
        } else {
            var keepgoing = false;
            if (nameid == 'mobile_number') {
                if (name.length == 16) {
                    keepgoing = true; // keep form from submitting
                }
            }
            if (nameid == 'name') {
                keepgoing = true;
            }
            if (nameid == 'address') {
                keepgoing = true;
            }
            if (nameid == 'pan_number') {
                if (name.length == 10) {
                    keepgoing = true; // keep form from submitting
                }
            }
            if (keepgoing) {
                e.preventDefault();
                var $next = $('[tabIndex=' + (+this.tabIndex + 1) + ']');
                console.log($next.length);
                var tabs = this.tabIndex + 1
                const otp_vide = document.querySelector("#otp_video").play()
            } else {
                var error_anim = document.getElementById(nameid);
                if (nameid == "mobile_number") {
                    error_anim = document.getElementById("mobile_number1");
                    error_anim.classList.add('animate__shakeX')
                    setTimeout(function() {
                        error_anim.classList.remove('animate__shakeX')
                    }, 3000);
                } else {
                    error_anim.classList.add('animate__shakeX')
                    setTimeout(function() {
                        error_anim.classList.remove('animate__shakeX')
                    }, 4000);
                    // alert('Please provide complete information')
                }
            }
        }
        // if all input are done then open 2nd section and play animation - start
        if (tabs == 5) {
            document.querySelector('#otp1').setAttribute('autofocus', 'autofocus');
            const anime_otp = document.querySelector("#Anime_otp");
            const buttons = document.querySelector("#buttons_otp");
            anime_otp.classList.add('animate__bounceInRight')
            setTimeout(function() {
                anime_otp.classList.remove('animate__bounceInRight')
            }, 4000);

            buttons.classList.add('animate__bounceInLeft')
            setTimeout(function() {
                buttons.classList.remove('animate__bounceInLeft')
            }, 4000);
        }
        if (!$next.length) {
            $next = $('[tabIndex=1]');
        }
        $next.focus().click();
    }
    // if all input are done then open 2nd section and play animation - end
});

// =================== checking mobile number start ===================
const isNumericInput = (event) => {
    const key = event.keyCode;
    return ((key >= 48 && key <= 57) || // Allow number line
        (key >= 96 && key <= 105) // Allow number pad
    );
};

const isModifierKey = (event) => {
    const key = event.keyCode;
    return (event.shiftKey === true || key === 35 || key === 36) || // Allow Shift, Home, End
        (key === 8 || key === 9 || key === 13 || key === 46) || // Allow Backspace, Tab, Enter, Delete
        (key > 36 && key < 41) || // Allow left, up, right, down
        (
            // Allow Ctrl/Command + A,C,V,X,Z
            (event.ctrlKey === true || event.metaKey === true) &&
            (key === 65 || key === 67 || key === 86 || key === 88 || key === 90)
        )
};

const enforceFormat = (event) => {
    // Input must be of a valid number format or a modifier key, and not longer than ten digits
    if (!isNumericInput(event) && !isModifierKey(event)) {
        event.preventDefault();
    }
};

const formatToPhone = (event) => {
    if (isModifierKey(event)) { return; }

    const input = event.target.value.replace(/\D/g, '').substring(0, 10); // First ten digits of input only
    const areaCode = input.substring(0, 3);
    const middle = input.substring(3, 6);
    const last = input.substring(6, 10);

    if (input.length > 6) { event.target.value = `(${areaCode}) ${middle} - ${last}`; } else if (input.length > 3) { event.target.value = `(${areaCode}) ${middle}`; } else if (input.length > 0) { event.target.value = `(${areaCode}`; }
};

const inputElement = document.getElementById('mobile_number');
inputElement.addEventListener('keydown', enforceFormat);
inputElement.addEventListener('keyup', formatToPhone);
// =================== checking mobile number end ===================

// 1st section input animation - start
function input_anime(ids) {
    const addanim = document.querySelector(ids);
    addanim.classList.add('animate__fadeInUpBig')
    setTimeout(function() {
        addanim.classList.remove('animate__fadeInUpBig')
    }, 30000);
}
// 1st section input animation - end

var viewId = 1;

//2nd section if all otp input are done then open 3rd section and play animation - start
function product() {
    function otp_error() {
        const addanim_opt = document.querySelector("#otp_container");
        addanim_opt.classList.add('animate__shakeX')
        setTimeout(function() {
            addanim_opt.classList.remove('animate__shakeX')
        }, 1000);
    }
    if (document.getElementById('otp1').value == '') {
        otp_error()
    } else if (document.getElementById('otp2').value == '') {
        otp_error()
    } else if (document.getElementById('otp3').value == '') {
        otp_error()
    } else if (document.getElementById('otp4').value == '') {
        otp_error()
    } else {
        console.log("hellonext");
        viewId = viewId + 1;
        progressBar();
        displayForms();
        console.log(viewId);
    }
}
//2nd section if all otp input are done then open 3rd section and play animation - end

//3rd section if one product select then open 4th section - start
function overview() {
    if (document.getElementById('p1').checked) {
        nextForm()
    } else if (document.getElementById('p2').checked) {
        nextForm()
    } else if (document.getElementById('p3').checked) {
        nextForm()
    } else {
        alert("please select one item")
    }
}
//3rd section if one product select then open 4th section - start

//4th section open 5th section - start
function nextForm() {
    viewId = viewId + 1;
    progressBar();
    displayForms();


}
//4th section open 5th section - start


// for changing section and progressbar - start
const nxtBtn = document.querySelector('#submitBtn');
const form1 = document.querySelector('#form1');
const form2 = document.querySelector('#form2');
const form3 = document.querySelector('#form3');
const form4 = document.querySelector('#form4');
const form5 = document.querySelector('#form5');


const icon1 = document.querySelector('#icon1');
const icon2 = document.querySelector('#icon2');
const icon3 = document.querySelector('#icon3');
const icon4 = document.querySelector('#icon4');
const icon5 = document.querySelector('#icon5');




function prevForm() {
    console.log("helloprev");
    viewId = viewId - 1;
    console.log(viewId);
    progressBar1();
    displayForms();
}

function progressBar1() {
    if (viewId === 1) {
        icon2.classList.add('active');
        icon2.classList.remove('active');
        icon3.classList.remove('active');
        icon4.classList.remove('active');
        icon5.classList.remove('active');
    }
    if (viewId === 2) {
        icon2.classList.add('active');
        icon3.classList.remove('active');
        icon4.classList.remove('active');
        icon5.classList.remove('active');
    }
    if (viewId === 3) {
        icon3.classList.add('active');
        icon4.classList.remove('active');
        icon5.classList.remove('active');
    }
    if (viewId === 4) {
        icon4.classList.add('active');
        icon5.classList.remove('active');
    }
    if (viewId === 5) {
        icon5.classList.add('active');
        nxtBtn.innerHTML = "Submit"
    }
    if (viewId > 5) {
        icon2.classList.remove('active');
        icon3.classList.remove('active');
        icon4.classList.remove('active');
        icon5.classList.remove('active');

    }
}

function progressBar() {
    if (viewId === 2) {
        icon2.classList.add('active');
    }
    if (viewId === 3) {
        icon3.classList.add('active');
    }
    if (viewId === 4) {
        icon4.classList.add('active');
    }
    if (viewId === 5) {
        icon5.classList.add('active');
    }
    if (viewId > 5) {
        icon2.classList.remove('active');
        icon3.classList.remove('active');
        icon4.classList.remove('active');
        icon5.classList.remove('active');

    }
}

function displayForms() {

    if (viewId > 5) {
        viewId = 1;
    }

    if (viewId === 1) {
        form1.style.display = 'block';
        form2.style.display = 'none';
        form3.style.display = 'none';
        form4.style.display = 'none';
        form5.style.display = 'none';


    } else if (viewId === 2) {
        form1.style.display = 'none';
        form2.style.display = 'block';
        form3.style.display = 'none';
        form4.style.display = 'none';
        form5.style.display = 'none';

    } else if (viewId === 3) {
        form1.style.display = 'none';
        form2.style.display = 'none';
        form3.style.display = 'block';
        form4.style.display = 'none';
        form5.style.display = 'none';
    } else if (viewId === 4) {
        form1.style.display = 'none';
        form2.style.display = 'none';
        form3.style.display = 'none';
        form4.style.display = 'block';
        form5.style.display = 'none';

    } else if (viewId === 5) {
        form1.style.display = 'none';
        form2.style.display = 'none';
        form3.style.display = 'none';
        form4.style.display = 'none';
        form5.style.display = 'block';

    }
}
// for changing section and progressbar - end

// for slider

var slider = document.querySelector(".slider");
var output = document.querySelector(".output__value");
output.innerHTML = slider.value;

slider.oninput = function() {
    output.innerHTML = this.value;
}